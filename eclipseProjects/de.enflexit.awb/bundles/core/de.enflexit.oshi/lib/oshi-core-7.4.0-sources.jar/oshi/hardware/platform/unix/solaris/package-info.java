/*
 * Copyright (c) 2016-2022 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
/**
 * Provides information about hardware such as Memory, Power Sources, and Processor on Solaris systems
 */
package oshi.hardware.platform.unix.solaris;
