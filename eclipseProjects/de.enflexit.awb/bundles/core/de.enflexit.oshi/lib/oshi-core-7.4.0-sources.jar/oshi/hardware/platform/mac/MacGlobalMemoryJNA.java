/*
 * Copyright 2025-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.hardware.platform.mac;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sun.jna.platform.mac.SystemB;

import oshi.annotation.concurrent.ThreadSafe;
import oshi.hardware.VirtualMemory;
import oshi.hardware.common.platform.mac.MacGlobalMemory;
import oshi.hardware.common.platform.mac.SysctlProvider;
import oshi.jna.ByRef.CloseableIntByReference;
import oshi.jna.ByRef.CloseableNativeLongByReference;
import oshi.jna.Struct.CloseableVMStatistics;

@ThreadSafe
final class MacGlobalMemoryJNA extends MacGlobalMemory {

    private static final Logger LOG = LoggerFactory.getLogger(MacGlobalMemoryJNA.class);

    @Override
    protected long queryVmStats() {
        try (CloseableVMStatistics vmStats = new CloseableVMStatistics();
                CloseableIntByReference size = new CloseableIntByReference(vmStats.size() / SystemB.INT_SIZE)) {
            int ret = SystemB.INSTANCE.host_statistics(SystemB.INSTANCE.mach_host_self(), SystemB.HOST_VM_INFO, vmStats,
                    size);
            if (0 != ret) {
                LOG.error("Failed to get host VM info. Error code: {}", ret);
                return 0L;
            }
            return (vmStats.free_count + vmStats.inactive_count) * getPageSize();
        }
    }

    @Override
    protected SysctlProvider sysctlProvider() {
        return SysctlProviderJNA.INSTANCE;
    }

    @Override
    protected long queryPageSize() {
        int ret = -1;
        try (CloseableNativeLongByReference pPageSize = new CloseableNativeLongByReference()) {
            ret = SystemB.INSTANCE.host_page_size(SystemB.INSTANCE.mach_host_self(), pPageSize);
            if (0 == ret) {
                return pPageSize.getValue().longValue();
            }
        }
        LOG.error("Failed to get host page size. Error code: {}", ret);
        return 4096L;
    }

    @Override
    protected VirtualMemory createVirtualMemory() {
        return new MacVirtualMemoryJNA(this);
    }

}
