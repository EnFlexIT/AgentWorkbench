/*
 * Copyright 2016-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.hardware.platform.mac;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sun.jna.platform.mac.SystemB;

import oshi.annotation.concurrent.ThreadSafe;
import oshi.hardware.common.platform.mac.IOKitProvider;
import oshi.hardware.common.platform.mac.MacCentralProcessor;
import oshi.hardware.common.platform.mac.SysctlProvider;
import oshi.jna.ByRef.CloseableIntByReference;
import oshi.jna.ByRef.CloseablePointerByReference;
import oshi.jna.Struct.CloseableHostCpuLoadInfo;
import oshi.util.FormatUtil;

/**
 * A CPU using JNA.
 */
@ThreadSafe
final class MacCentralProcessorJNA extends MacCentralProcessor {

    private static final Logger LOG = LoggerFactory.getLogger(MacCentralProcessorJNA.class);

    @Override
    protected SysctlProvider sysctlProvider() {
        return SysctlProviderJNA.INSTANCE;
    }

    @Override
    public long[] querySystemCpuLoadTicks() {
        long[] ticks = new long[TickType.values().length];
        int machPort = SystemB.INSTANCE.mach_host_self();
        try (CloseableHostCpuLoadInfo cpuLoadInfo = new CloseableHostCpuLoadInfo();
                CloseableIntByReference size = new CloseableIntByReference(cpuLoadInfo.size())) {
            int ret = SystemB.INSTANCE.host_statistics(machPort, SystemB.HOST_CPU_LOAD_INFO, cpuLoadInfo, size);
            if (0 != ret) {
                LOG.error("Failed to get System CPU ticks. Error code: {} ", ret);
                return ticks;
            }

            ticks[TickType.USER.getIndex()] = FormatUtil.getUnsignedInt(cpuLoadInfo.cpu_ticks[SystemB.CPU_STATE_USER]);
            ticks[TickType.NICE.getIndex()] = FormatUtil.getUnsignedInt(cpuLoadInfo.cpu_ticks[SystemB.CPU_STATE_NICE]);
            ticks[TickType.SYSTEM.getIndex()] = FormatUtil
                    .getUnsignedInt(cpuLoadInfo.cpu_ticks[SystemB.CPU_STATE_SYSTEM]);
            ticks[TickType.IDLE.getIndex()] = FormatUtil.getUnsignedInt(cpuLoadInfo.cpu_ticks[SystemB.CPU_STATE_IDLE]);
        }
        return ticks;
    }

    @Override
    public double[] getSystemLoadAverage(int nelem) {
        if (nelem < 1 || nelem > 3) {
            throw new IllegalArgumentException("Must include from one to three elements.");
        }
        double[] average = new double[nelem];
        int retval = SystemB.INSTANCE.getloadavg(average, nelem);
        if (retval < nelem) {
            Arrays.fill(average, -1d);
        }
        return average;
    }

    @Override
    protected IOKitProvider ioKitProvider() {
        return IOKitProviderJNA.INSTANCE;
    }

    @Override
    public long[][] queryProcessorCpuLoadTicks() {
        long[][] ticks = new long[getLogicalProcessorCount()][TickType.values().length];

        int machPort = SystemB.INSTANCE.mach_host_self();
        try (CloseableIntByReference procCount = new CloseableIntByReference();
                CloseablePointerByReference procCpuLoadInfo = new CloseablePointerByReference();
                CloseableIntByReference procInfoCount = new CloseableIntByReference()) {
            int ret = SystemB.INSTANCE.host_processor_info(machPort, SystemB.PROCESSOR_CPU_LOAD_INFO, procCount,
                    procCpuLoadInfo, procInfoCount);
            if (0 != ret) {
                LOG.error("Failed to update CPU Load. Error code: {}", ret);
                return ticks;
            }
            try {
                int[] cpuTicks = procCpuLoadInfo.getValue().getIntArray(0, procInfoCount.getValue());
                for (int cpu = 0; cpu < procCount.getValue(); cpu++) {
                    int offset = cpu * SystemB.CPU_STATE_MAX;
                    ticks[cpu][TickType.USER.getIndex()] = FormatUtil
                            .getUnsignedInt(cpuTicks[offset + SystemB.CPU_STATE_USER]);
                    ticks[cpu][TickType.NICE.getIndex()] = FormatUtil
                            .getUnsignedInt(cpuTicks[offset + SystemB.CPU_STATE_NICE]);
                    ticks[cpu][TickType.SYSTEM.getIndex()] = FormatUtil
                            .getUnsignedInt(cpuTicks[offset + SystemB.CPU_STATE_SYSTEM]);
                    ticks[cpu][TickType.IDLE.getIndex()] = FormatUtil
                            .getUnsignedInt(cpuTicks[offset + SystemB.CPU_STATE_IDLE]);
                }
            } finally {
                try {
                    SystemB.INSTANCE.vm_deallocate(SystemB.INSTANCE.mach_task_self(),
                            com.sun.jna.Pointer.nativeValue(procCpuLoadInfo.getValue()),
                            (long) procInfoCount.getValue() * SystemB.INT_SIZE);
                } catch (Exception e) {
                    LOG.warn("Failed to vm_deallocate processor info buffer", e);
                }
            }
        }
        return ticks;
    }

}
