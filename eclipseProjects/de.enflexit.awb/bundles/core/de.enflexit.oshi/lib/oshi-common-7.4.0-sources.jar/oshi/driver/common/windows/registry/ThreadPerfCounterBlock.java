/*
 * Copyright 2020-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.driver.common.windows.registry;

import oshi.annotation.concurrent.Immutable;

/**
 * Encapsulates thread performance data from the registry performance counter block.
 */
@Immutable
public final class ThreadPerfCounterBlock {
    private final String name;
    private final int threadID;
    private final int owningProcessID;
    private final long startTime;
    private final long userTime;
    private final long kernelTime;
    private final int priority;
    private final int threadState;
    private final int threadWaitReason;
    private final long startAddress;
    private final long contextSwitches;

    /**
     * Constructor.
     *
     * @param name             the name
     * @param threadID         the threadID
     * @param owningProcessID  the owningProcessID
     * @param startTime        the startTime
     * @param userTime         the userTime
     * @param kernelTime       the kernelTime
     * @param priority         the priority
     * @param threadState      the threadState
     * @param threadWaitReason the threadWaitReason
     * @param startAddress     the startAddress
     * @param contextSwitches  the contextSwitches
     */
    public ThreadPerfCounterBlock(String name, int threadID, int owningProcessID, long startTime, long userTime,
            long kernelTime, int priority, int threadState, int threadWaitReason, long startAddress,
            long contextSwitches) {
        this.name = name;
        this.threadID = threadID;
        this.owningProcessID = owningProcessID;
        this.startTime = startTime;
        this.userTime = userTime;
        this.kernelTime = kernelTime;
        this.priority = priority;
        this.threadState = threadState;
        this.threadWaitReason = threadWaitReason;
        this.startAddress = startAddress;
        this.contextSwitches = contextSwitches;
    }

    /**
     * Gets the name.
     *
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the threadID.
     *
     * @return the threadID
     */
    public int getThreadID() {
        return threadID;
    }

    /**
     * Gets the owningProcessID.
     *
     * @return the owningProcessID
     */
    public int getOwningProcessID() {
        return owningProcessID;
    }

    /**
     * Gets the startTime.
     *
     * @return the startTime
     */
    public long getStartTime() {
        return startTime;
    }

    /**
     * Gets the userTime.
     *
     * @return the userTime
     */
    public long getUserTime() {
        return userTime;
    }

    /**
     * Gets the kernelTime.
     *
     * @return the kernelTime
     */
    public long getKernelTime() {
        return kernelTime;
    }

    /**
     * Gets the priority.
     *
     * @return the priority
     */
    public int getPriority() {
        return priority;
    }

    /**
     * Gets the threadState.
     *
     * @return the threadState
     */
    public int getThreadState() {
        return threadState;
    }

    /**
     * Gets the threadWaitReason.
     *
     * @return the threadWaitReason
     */
    public int getThreadWaitReason() {
        return threadWaitReason;
    }

    /**
     * Gets the startMemoryAddress.
     *
     * @return the startMemoryAddress
     */
    public long getStartAddress() {
        return startAddress;
    }

    /**
     * Gets the contextSwitches.
     *
     * @return the contextSwitches
     */
    public long getContextSwitches() {
        return contextSwitches;
    }
}
