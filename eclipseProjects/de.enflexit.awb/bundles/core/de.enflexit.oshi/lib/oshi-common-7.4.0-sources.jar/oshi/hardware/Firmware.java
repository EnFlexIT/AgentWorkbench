/*
 * Copyright 2016-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.hardware;

import oshi.annotation.PublicApi;
import oshi.annotation.concurrent.Immutable;

/**
 * The Firmware represents the low level BIOS or equivalent.
 * <p>
 * Obtained from {@link ComputerSystem#getFirmware()}.
 * <p>
 * <b>Platform notes:</b> On Raspberry Pi, {@code vcgencmd} is used as a fallback to retrieve firmware version
 * information when standard SMBIOS data is not available.
 *
 * @see ComputerSystem
 */
@PublicApi
@Immutable
public interface Firmware {

    /**
     * Get the firmware manufacturer.
     *
     * @return the manufacturer
     */
    String getManufacturer();

    /**
     * Get the firmware name.
     *
     * @return the name
     */
    String getName();

    /**
     * Get the firmware description.
     *
     * @return the description
     */
    String getDescription();

    /**
     * Get the firmware version.
     *
     * @return the version
     */
    String getVersion();

    /**
     * Get the firmware release date.
     *
     * @return The release date.
     */
    String getReleaseDate();
}
