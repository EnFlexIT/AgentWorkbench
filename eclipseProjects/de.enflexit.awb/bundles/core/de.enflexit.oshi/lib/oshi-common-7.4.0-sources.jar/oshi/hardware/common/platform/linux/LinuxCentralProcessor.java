/*
 * Copyright 2016-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.hardware.common.platform.linux;

import static oshi.util.linux.ProcPath.CPUINFO;
import static oshi.util.linux.ProcPath.LOADAVG;
import static oshi.util.linux.ProcPath.MODEL;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.LongStream;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import oshi.annotation.concurrent.ThreadSafe;
import oshi.hardware.CentralProcessor.ProcessorCache.Type;
import oshi.hardware.common.AbstractCentralProcessor;
import oshi.util.ExecutingCommand;
import oshi.util.FileUtil;
import oshi.util.ParseUtil;
import oshi.util.Util;
import oshi.util.driver.linux.Lshw;
import oshi.util.driver.linux.proc.CpuInfo;
import oshi.util.driver.linux.proc.CpuStat;
import oshi.util.linux.SysPath;
import oshi.util.tuples.Quartet;

/**
 * A CPU as defined in Linux /proc.
 */
@ThreadSafe
public abstract class LinuxCentralProcessor extends AbstractCentralProcessor {

    private static final Logger LOG = LoggerFactory.getLogger(LinuxCentralProcessor.class);

    private final long hz;

    /**
     * LinuxCentralProcessor.
     *
     * @param hz the hz
     */
    protected LinuxCentralProcessor(long hz) {
        this.hz = hz;
    }

    @Override
    protected ProcessorIdentifier queryProcessorId() {
        String cpuVendor = "";
        String cpuName = "";
        String cpuFamily = "";
        String cpuModel = "";
        String cpuStepping = "";
        String processorID;
        long cpuFreq = 0L;
        boolean cpu64bit = false;

        StringBuilder armStepping = new StringBuilder(); // For ARM equivalent
        String[] flags = new String[0];
        List<String> cpuInfo = FileUtil.readFile(CPUINFO);
        for (String line : cpuInfo) {
            String[] splitLine = ParseUtil.whitespacesColonWhitespace.split(line);
            if (splitLine.length < 2) {
                // special case
                if (line.startsWith("CPU architecture: ")) {
                    cpuFamily = line.replace("CPU architecture: ", "").trim();
                }
                continue;
            }
            switch (splitLine[0].toLowerCase(Locale.ROOT)) {
                case "vendor_id":
                case "cpu implementer":
                    cpuVendor = splitLine[1];
                    break;
                case "model name":
                case "processor": // some ARM chips
                    // Ignore processor number
                    if (!splitLine[1].matches("\\d+")) {
                        cpuName = splitLine[1];
                    }
                    break;
                case "flags":
                    flags = splitLine[1].toLowerCase(Locale.ROOT).split(" ");
                    for (String flag : flags) {
                        if ("lm".equals(flag)) {
                            cpu64bit = true;
                            break;
                        }
                    }
                    break;
                case "stepping":
                    cpuStepping = splitLine[1];
                    break;
                case "cpu variant":
                    if (!armStepping.toString().startsWith("r")) {
                        // CPU variant format always starts with 0x
                        int rev = ParseUtil.parseLastInt(splitLine[1], 0);
                        armStepping.insert(0, "r" + rev);
                    }
                    break;
                case "cpu revision":
                    if (!armStepping.toString().contains("p")) {
                        armStepping.append('p').append(splitLine[1]);
                    }
                    break;
                case "model":
                case "cpu part":
                    cpuModel = splitLine[1];
                    break;
                case "cpu family":
                    cpuFamily = splitLine[1];
                    break;
                case "cpu mhz":
                    cpuFreq = ParseUtil.parseHertz(splitLine[1]);
                    break;
                default:
                    // Do nothing
            }
        }
        if (cpuName.isEmpty()) {
            cpuName = FileUtil.getStringFromFile(MODEL).trim();
        }
        if (cpuName.contains("Hz")) {
            // if Name contains CPU vendor frequency, ignore cpuinfo and use it
            cpuFreq = -1L;
        } else {
            // Try lshw and use it in preference to cpuinfo
            long cpuCapacity = Lshw.queryCpuCapacity();
            if (cpuCapacity > cpuFreq) {
                cpuFreq = cpuCapacity;
            }
        }
        if (cpuStepping.isEmpty()) {
            cpuStepping = armStepping.toString();
        }
        processorID = getProcessorID(cpuVendor, cpuStepping, cpuModel, cpuFamily, flags, queryHwcap());
        if (cpuVendor.startsWith("0x") || cpuModel.isEmpty() || cpuName.isEmpty()) {
            List<String> lscpu = ExecutingCommand.runNative("lscpu");
            for (String line : lscpu) {
                if (line.startsWith("Architecture:") && cpuVendor.startsWith("0x")) {
                    cpuVendor = line.replace("Architecture:", "").trim();
                } else if (line.startsWith("Vendor ID:")) {
                    cpuVendor = line.replace("Vendor ID:", "").trim();
                } else if (line.startsWith("Model name:")) {
                    String modelName = line.replace("Model name:", "").trim();
                    cpuModel = cpuModel.isEmpty() ? modelName : cpuModel;
                    cpuName = cpuName.isEmpty() ? modelName : cpuName;
                }
            }
        }
        return new ProcessorIdentifier(cpuVendor, cpuName, cpuFamily, cpuModel, cpuStepping, processorID, cpu64bit,
                cpuFreq);
    }

    @Override
    protected Quartet<List<LogicalProcessor>, List<PhysicalProcessor>, List<ProcessorCache>, List<String>> initProcessorCounts() {
        // Attempt to read from sysfs
        Quartet<List<LogicalProcessor>, List<ProcessorCache>, Map<Integer, Integer>, Map<Integer, String>> topology = readTopologyWithUdev();
        // This sometimes fails so fall back to CPUID
        if (topology.getA().isEmpty()) {
            topology = readTopologyFromCpuinfo();
        }
        List<LogicalProcessor> logProcs = topology.getA();
        List<ProcessorCache> caches = topology.getB();
        Map<Integer, Integer> coreEfficiencyMap = topology.getC();
        Map<Integer, String> modAliasMap = topology.getD();
        // Failsafe
        if (logProcs.isEmpty()) {
            logProcs.add(new LogicalProcessor(0, 0, 0));
        }
        if (coreEfficiencyMap.isEmpty()) {
            coreEfficiencyMap.put(0, 0);
        }
        // Sort
        logProcs.sort(Comparator.comparingInt(LogicalProcessor::getProcessorNumber));

        List<PhysicalProcessor> physProcs = coreEfficiencyMap.entrySet().stream().sorted(Map.Entry.comparingByKey())
                .map(e -> {
                    int pkgId = e.getKey() >> 16;
                    int coreId = e.getKey() & 0xffff;
                    return new PhysicalProcessor(pkgId, coreId, e.getValue(), modAliasMap.getOrDefault(e.getKey(), ""));
                }).collect(Collectors.toList());
        List<String> featureFlags = CpuInfo.queryFeatureFlags();
        return new Quartet<>(logProcs, physProcs, caches, featureFlags);
    }

    /**
     * Reads processor topology using udev.
     *
     * @return a quartet of logical processors, caches, efficiency map, and modalias map
     */
    protected abstract Quartet<List<LogicalProcessor>, List<ProcessorCache>, Map<Integer, Integer>, Map<Integer, String>> readTopologyWithUdev();

    /**
     * Reads processor topology from sysfs using the default CPU path.
     *
     * @return a quartet of logical processors, caches, efficiency map, and modalias map
     */
    protected static Quartet<List<LogicalProcessor>, List<ProcessorCache>, Map<Integer, Integer>, Map<Integer, String>> readTopologyFromSysfs() {
        return readTopologyFromSysfs(SysPath.CPU);
    }

    static Quartet<List<LogicalProcessor>, List<ProcessorCache>, Map<Integer, Integer>, Map<Integer, String>> readTopologyFromSysfs(
            String cpuPath) {
        List<LogicalProcessor> logProcs = new ArrayList<>();
        Set<ProcessorCache> caches = new HashSet<>();
        Map<Integer, Integer> coreEfficiencyMap = new HashMap<>();
        Map<Integer, String> modAliasMap = new HashMap<>();
        try {
            try (Stream<Path> cpuFiles = Files.find(Paths.get(cpuPath), Integer.MAX_VALUE,
                    (path, basicFileAttributes) -> path.toFile().getName().matches("cpu\\d+"))) {
                cpuFiles.forEach(cpu -> {
                    String syspath = cpu.toString(); // /sys/devices/system/cpu/cpuX
                    Map<String, String> uevent = FileUtil.getKeyValueMapFromFile(syspath + "/uevent", "=");
                    String modAlias = uevent.get("MODALIAS");
                    // updates caches as a side-effect
                    logProcs.add(
                            getLogicalProcessorFromSyspath(syspath, caches, modAlias, coreEfficiencyMap, modAliasMap));
                });
            }
        } catch (IOException e) {
            // No udev and no cpu info in sysfs? Bad.
            LOG.warn("Unable to find CPU information in sysfs at path {}", cpuPath);
        }
        return new Quartet<>(logProcs, orderedProcCaches(caches), coreEfficiencyMap, modAliasMap);
    }

    /**
     * getLogicalProcessorFromSyspath.
     *
     * @param syspath           the syspath
     * @param caches            the caches
     * @param modAlias          the modAlias
     * @param coreEfficiencyMap the coreEfficiencyMap
     * @param modAliasMap       the modAliasMap
     * @return a LogicalProcessor for the given syspath
     */
    protected static LogicalProcessor getLogicalProcessorFromSyspath(String syspath, Set<ProcessorCache> caches,
            String modAlias, Map<Integer, Integer> coreEfficiencyMap, Map<Integer, String> modAliasMap) {
        int processor = ParseUtil.getFirstIntValue(syspath);
        int coreId = FileUtil.getIntFromFile(syspath + "/topology/core_id");
        int pkgId = FileUtil.getIntFromFile(syspath + "/topology/physical_package_id");
        int pkgCoreKey = (pkgId << 16) + coreId;
        // The cpu_capacity value may not exist, this will just store 0
        coreEfficiencyMap.put(pkgCoreKey, FileUtil.getIntFromFile(syspath + "/cpu_capacity"));
        if (!Util.isBlank(modAlias)) {
            modAliasMap.put(pkgCoreKey, modAlias);
        }
        int nodeId = 0;
        final String nodePrefix = Paths.get(syspath, "node").toString();
        try (Stream<Path> path = Files.list(Paths.get(syspath))) {
            Optional<Path> first = path.filter(p -> p.toString().startsWith(nodePrefix)).findFirst();
            if (first.isPresent()) {
                nodeId = ParseUtil.getFirstIntValue(FileUtil.getFileName(first.get().toString()));
            }
        } catch (IOException e) {
            // ignore
        }
        final String cachePath = Paths.get(syspath, "cache").toString();
        final String indexPrefix = Paths.get(cachePath, "index").toString();
        try (Stream<Path> path = Files.list(Paths.get(cachePath))) {
            path.filter(p -> p.toString().startsWith(indexPrefix)).forEach(c -> {
                int level = FileUtil.getIntFromFile(c + "/level"); // 1
                Type type = parseCacheType(FileUtil.getStringFromFile(c + "/type")); // Data
                int associativity = FileUtil.getIntFromFile(c + "/ways_of_associativity"); // 8
                int lineSize = FileUtil.getIntFromFile(c + "/coherency_line_size"); // 64
                long size = ParseUtil.parseDecimalMemorySizeToBinary(FileUtil.getStringFromFile(c + "/size")); // 32K
                caches.add(new ProcessorCache(level, associativity, lineSize, size, type));
            });
        } catch (IOException e) {
            // ignore
        }
        return new LogicalProcessor(processor, coreId, pkgId, nodeId);
    }

    private static ProcessorCache.Type parseCacheType(String type) {
        try {
            return ProcessorCache.Type.valueOf(type.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            return ProcessorCache.Type.UNIFIED;
        }
    }

    private static Quartet<List<LogicalProcessor>, List<ProcessorCache>, Map<Integer, Integer>, Map<Integer, String>> readTopologyFromCpuinfo() {
        return readTopologyFromCpuinfo(FileUtil.readFile(CPUINFO));
    }

    static Quartet<List<LogicalProcessor>, List<ProcessorCache>, Map<Integer, Integer>, Map<Integer, String>> readTopologyFromCpuinfo(
            List<String> procCpu) {
        List<LogicalProcessor> logProcs = new ArrayList<>();
        Set<ProcessorCache> caches = mapCachesFromLscpu();
        Map<Integer, Integer> numaNodeMap = mapNumaNodesFromLscpu();
        Map<Integer, Integer> coreEfficiencyMap = new HashMap<>();

        int currentProcessor = 0;
        int currentCore = 0;
        int currentPackage = 0;

        boolean first = true;
        for (String cpu : procCpu) {
            // Count logical processors
            if (cpu.startsWith("processor")) {
                if (first) {
                    first = false;
                } else {
                    // add from the previous iteration
                    logProcs.add(new LogicalProcessor(currentProcessor, currentCore, currentPackage,
                            numaNodeMap.getOrDefault(currentProcessor, 0)));
                    // Count unique combinations of core id and physical id.
                    coreEfficiencyMap.put((currentPackage << 16) + currentCore, 0);
                }
                // start creating for this iteration
                currentProcessor = ParseUtil.parseLastInt(cpu, 0);
            } else if (cpu.startsWith("core id") || cpu.startsWith("cpu number")) {
                currentCore = ParseUtil.parseLastInt(cpu, 0);
            } else if (cpu.startsWith("physical id")) {
                currentPackage = ParseUtil.parseLastInt(cpu, 0);
            }
        }
        logProcs.add(new LogicalProcessor(currentProcessor, currentCore, currentPackage,
                numaNodeMap.getOrDefault(currentProcessor, 0)));
        coreEfficiencyMap.put((currentPackage << 16) + currentCore, 0);
        return new Quartet<>(logProcs, orderedProcCaches(caches), coreEfficiencyMap, Collections.emptyMap());
    }

    private static Map<Integer, Integer> mapNumaNodesFromLscpu() {
        return mapNumaNodesFromLscpu(ExecutingCommand.runNative("lscpu -p=cpu,node"));
    }

    /**
     * Parse NUMA node mapping from lscpu output.
     *
     * @param lscpu output of {@code lscpu -p=cpu,node}
     * @return a map of logical processor number to NUMA node
     */
    static Map<Integer, Integer> mapNumaNodesFromLscpu(List<String> lscpu) {
        Map<Integer, Integer> numaNodeMap = new HashMap<>();
        // Format:
        // # comment lines starting with #
        // # then comma-delimited cpu,node
        // 0,0
        // 1,0
        for (String line : lscpu) {
            if (!line.startsWith("#")) {
                int pos = line.indexOf(',');
                if (pos > 0 && pos < line.length()) {
                    numaNodeMap.put(ParseUtil.parseIntOrDefault(line.substring(0, pos), 0),
                            ParseUtil.parseIntOrDefault(line.substring(pos + 1), 0));
                }
            }
        }
        return numaNodeMap;
    }

    private static Set<ProcessorCache> mapCachesFromLscpu() {
        return mapCachesFromLscpu(ExecutingCommand.runNative("lscpu -B -C --json"));
    }

    /**
     * Parse processor cache information from lscpu JSON output.
     *
     * @param lscpu output of {@code lscpu -B -C --json}
     * @return a set of processor caches
     */
    static Set<ProcessorCache> mapCachesFromLscpu(List<String> lscpu) {
        Set<ProcessorCache> caches = new HashSet<>();
        int level = 0;
        Type type = null;
        int associativity = 0;
        int lineSize = 0;
        long size = 0L;
        for (String line : lscpu) {
            String s = line.trim();
            if (s.startsWith("}")) {
                // done with this entry, save it
                if (level > 0 && type != null) {
                    caches.add(new ProcessorCache(level, associativity, lineSize, size, type));
                }
                level = 0;
                type = null;
                associativity = 0;
                lineSize = 0;
                size = 0L;
            } else if (s.contains("one-size")) {
                // "one-size": "65536",
                String[] split = ParseUtil.notDigits.split(s);
                if (split.length > 1) {
                    size = ParseUtil.parseLongOrDefault(split[1], 0L);
                }
            } else if (s.contains("ways")) {
                // "ways": null,
                // "ways": 4,
                String[] split = ParseUtil.notDigits.split(s);
                if (split.length > 1) {
                    associativity = ParseUtil.parseIntOrDefault(split[1], 0);
                }
            } else if (s.contains("type")) {
                // "type": "Unified",
                String[] split = s.split("\"");
                if (split.length > 2) {
                    type = parseCacheType(split[split.length - 2]);
                }
            } else if (s.contains("level")) {
                // "level": 3,
                String[] split = ParseUtil.notDigits.split(s);
                if (split.length > 1) {
                    level = ParseUtil.parseIntOrDefault(split[1], 0);
                }
            } else if (s.contains("coherency-size")) {
                // "coherency-size": 64
                String[] split = ParseUtil.notDigits.split(s);
                if (split.length > 1) {
                    lineSize = ParseUtil.parseIntOrDefault(split[1], 0);
                }
            }
        }
        return caches;
    }

    @Override
    public long[] querySystemCpuLoadTicks() {
        long[] ticks = CpuStat.getSystemCpuLoadTicks();
        // In rare cases, /proc/stat reading fails. If so, try again.
        if (LongStream.of(ticks).sum() == 0) {
            ticks = CpuStat.getSystemCpuLoadTicks();
        }
        for (int i = 0; i < ticks.length; i++) {
            ticks[i] = ticks[i] * 1000L / hz;
        }
        return ticks;
    }

    @Override
    public long[] queryCurrentFreq() {
        long[] freqs = new long[getLogicalProcessorCount()];
        if (queryCurrentFreqFromUdev(freqs)) {
            return freqs;
        }
        // Fall back to /proc/cpuinfo
        Arrays.fill(freqs, -1);
        List<String> cpuInfo = FileUtil.readFile(CPUINFO);
        int proc = 0;
        for (String s : cpuInfo) {
            if (s.toLowerCase(Locale.ROOT).contains("cpu mhz")) {
                freqs[proc] = Math.round(ParseUtil.parseLastDouble(s, 0d) * 1_000_000d);
                if (++proc >= freqs.length) {
                    break;
                }
            }
        }
        return freqs;
    }

    /**
     * Fills the freqs array from udev cpu-freq source. Returns true if successful (max > 0). Subclasses provide the
     * implementation.
     *
     * @param freqs array to fill with per-logical-processor frequencies in Hz
     * @return true if frequencies were successfully read
     */
    protected abstract boolean queryCurrentFreqFromUdev(long[] freqs);

    /**
     * queryCurrentFreqFromSysfs.
     *
     * @param freqs the freqs
     * @return the result
     */
    protected static boolean queryCurrentFreqFromSysfs(long[] freqs) {
        long max = 0L;
        try (Stream<Path> cpuFiles = Files.find(Paths.get(SysPath.CPU), 1,
                (path, attr) -> path.toFile().getName().matches("cpu\\d+"))) {
            for (Path cpu : (Iterable<Path>) cpuFiles::iterator) {
                String syspath = cpu.toString();
                int cpuIdx = ParseUtil.getFirstIntValue(syspath);
                if (cpuIdx >= 0 && cpuIdx < freqs.length) {
                    freqs[cpuIdx] = FileUtil.getLongFromFile(syspath + "/cpufreq/scaling_cur_freq");
                    if (freqs[cpuIdx] == 0) {
                        freqs[cpuIdx] = FileUtil.getLongFromFile(syspath + "/cpufreq/cpuinfo_cur_freq");
                    }
                    if (max < freqs[cpuIdx]) {
                        max = freqs[cpuIdx];
                    }
                }
            }
        } catch (IOException e) {
            // ignore
        }
        if (max > 0L) {
            for (int i = 0; i < freqs.length; i++) {
                freqs[i] *= 1000L;
            }
            return true;
        }
        return false;
    }

    @Override
    public long queryMaxFreq() {
        long policyMax = queryMaxFreqFromUdev();
        long lshwMax = Lshw.queryCpuCapacity();
        return LongStream.concat(LongStream.of(policyMax, lshwMax), Arrays.stream(this.getCurrentFreq())).max()
                .orElse(-1L);
    }

    /**
     * Queries the maximum frequency from udev.
     *
     * @return the maximum frequency in Hz
     */
    protected abstract long queryMaxFreqFromUdev();

    /**
     * Queries the maximum frequency from sysfs.
     *
     * @return the maximum frequency in Hz
     */
    protected static long queryMaxFreqFromSysfs() {
        return queryMaxFreqFromCpuFreqPath(SysPath.CPU.substring(0, SysPath.CPU.length() - 1) + "/cpufreq");
    }

    /**
     * Queries the maximum frequency from a cpufreq path.
     *
     * @param cpuFreqPath the cpufreq directory path
     * @return the maximum frequency in Hz
     */
    protected static long queryMaxFreqFromCpuFreqPath(String cpuFreqPath) {
        String policyPrefix = Paths.get(cpuFreqPath, "policy").toString();
        try (Stream<Path> path = Files.list(Paths.get(cpuFreqPath))) {
            Optional<Long> maxPolicy = path.filter(p -> p.toString().startsWith(policyPrefix)).map(p -> {
                long freq = FileUtil.getLongFromFile(p.toString() + "/scaling_max_freq");
                if (freq == 0) {
                    freq = FileUtil.getLongFromFile(p.toString() + "/cpuinfo_max_freq");
                }
                return freq;
            }).max(Long::compare);
            if (maxPolicy.isPresent()) {
                return maxPolicy.get() * 1000L;
            }
        } catch (IOException e) {
            // ignore
        }
        return -1L;
    }

    @Override
    public double[] getSystemLoadAverage(int nelem) {
        return getSystemLoadAverage(nelem, FileUtil.getStringFromFile(LOADAVG));
    }

    static double[] getSystemLoadAverage(int nelem, String loadavgContent) {
        if (nelem < 1 || nelem > 3) {
            throw new IllegalArgumentException("Must include from one to three elements.");
        }
        double[] average = new double[nelem];
        String[] parts = ParseUtil.whitespaces.split(loadavgContent.trim());
        for (int i = 0; i < nelem; i++) {
            average[i] = i < parts.length ? ParseUtil.parseDoubleOrDefault(parts[i], -1d) : -1d;
        }
        return average;
    }

    @Override
    public long[][] queryProcessorCpuLoadTicks() {
        long[][] ticks = CpuStat.getProcessorCpuLoadTicks(getLogicalProcessorCount());
        // In rare cases, /proc/stat reading fails. If so, try again.
        // In theory we should check all of them, but on failure we can expect all 0's
        // so we only need to check for processor 0
        if (LongStream.of(ticks[0]).sum() == 0) {
            ticks = CpuStat.getProcessorCpuLoadTicks(getLogicalProcessorCount());
        }
        for (int i = 0; i < ticks.length; i++) {
            for (int j = 0; j < ticks[i].length; j++) {
                ticks[i][j] = ticks[i][j] * 1000L / hz;
            }
        }
        return ticks;
    }

    /**
     * Fetches the ProcessorID from dmidecode (if possible with root permissions), the cpuid command (if installed) or
     * by encoding the stepping, model, family, and feature flags.
     *
     * @param vendor   The vendor
     * @param stepping The stepping
     * @param model    The model
     * @param family   The family
     * @param flags    The flags
     * @param hwcap    Hardware capabilities from the auxiliary vector, or 0 if unavailable
     * @return The Processor ID string
     */
    private static String getProcessorID(String vendor, String stepping, String model, String family, String[] flags,
            long hwcap) {
        boolean procInfo = false;
        String marker = "Processor Information";
        for (String checkLine : ExecutingCommand.runPrivilegedNative("dmidecode -t 4")) {
            if (!procInfo && checkLine.contains(marker)) {
                marker = "ID:";
                procInfo = true;
            } else if (procInfo && checkLine.contains(marker)) {
                return checkLine.split(marker)[1].trim();
            }
        }
        // If we've gotten this far, dmidecode failed. Try cpuid.
        String cpuidResult = parseCpuidOutput(ExecutingCommand.runNative("cpuid -1r"));
        if (cpuidResult != null) {
            return cpuidResult;
        }
        // If we've gotten this far, dmidecode failed. Encode arguments
        if (vendor.startsWith("0x")) {
            return createMIDR(vendor, stepping, model, family) + "00000000";
        }
        return createProcessorID(stepping, model, family, flags, hwcap);
    }

    /**
     * Parses the output of {@code cpuid -1r} to extract the processor ID.
     *
     * @param cpuidLines the output lines from {@code cpuid -1r}
     * @return the processor ID string (edx + eax), or {@code null} if not found
     */
    static String parseCpuidOutput(List<String> cpuidLines) {
        for (String checkLine : cpuidLines) {
            if (checkLine.contains("eax=") && checkLine.trim().startsWith("0x00000001")) {
                String eax = "";
                String edx = "";
                for (String register : ParseUtil.whitespaces.split(checkLine)) {
                    if (register.startsWith("eax=")) {
                        eax = ParseUtil.removeMatchingString(register, "eax=0x");
                    } else if (register.startsWith("edx=")) {
                        edx = ParseUtil.removeMatchingString(register, "edx=0x");
                    }
                }
                if (!eax.isEmpty() && !edx.isEmpty()) {
                    return edx + eax;
                }
            }
        }
        return null;
    }

    /**
     * Queries the hardware capabilities from the auxiliary vector. Subclasses provide platform-specific implementations
     * using JNA or FFM native access.
     *
     * @return The hardware capabilities value, or 0 if unavailable
     */
    protected long queryHwcap() {
        return 0L;
    }

    /**
     * Creates the MIDR, the ARM equivalent of CPUID ProcessorID
     *
     * @param vendor   the CPU implementer
     * @param stepping the "rnpn" variant and revision
     * @param model    the partnum
     * @param family   the architecture
     * @return A 32-bit hex string for the MIDR
     */
    static String createMIDR(String vendor, String stepping, String model, String family) {
        int midrBytes = 0;
        // Build 32-bit MIDR
        if (stepping.startsWith("r") && stepping.contains("p")) {
            String[] rev = stepping.substring(1).split("p");
            // 3:0 – Revision: last n in rnpn
            midrBytes |= ParseUtil.parseLastInt(rev[1], 0);
            // 23:20 - Variant: first n in rnpn
            midrBytes |= ParseUtil.parseLastInt(rev[0], 0) << 20;
        }
        // 15:4 - PartNum = model
        midrBytes |= ParseUtil.parseLastInt(model, 0) << 4;
        // 19:16 - Architecture = family
        midrBytes |= ParseUtil.parseLastInt(family, 0) << 16;
        // 31:24 - Implementer = vendor
        midrBytes |= ParseUtil.parseLastInt(vendor, 0) << 24;

        return String.format(Locale.ROOT, "%08X", midrBytes);
    }

    @Override
    public long queryContextSwitches() {
        return CpuStat.getContextSwitches();
    }

    @Override
    public long queryInterrupts() {
        return CpuStat.getInterrupts();
    }
}
