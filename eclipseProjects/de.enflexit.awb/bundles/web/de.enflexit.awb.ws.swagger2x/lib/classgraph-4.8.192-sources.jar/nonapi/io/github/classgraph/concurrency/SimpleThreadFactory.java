/*
 * This file is part of ClassGraph.
 *
 * Author: Johno Crawford (johno@sulake.com)
 *
 * Hosted at: https://github.com/classgraph/classgraph
 *
 * --
 *
 * The MIT License (MIT)
 *
 * Copyright (c) 2016 Johno Crawford
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without
 * limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial
 * portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT
 * LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO
 * EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
 * AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE
 * OR OTHER DEALINGS IN THE SOFTWARE.
 */
package nonapi.io.github.classgraph.concurrency;

import java.lang.reflect.Method;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Simple implementation of a thread factory.
 *
 * @author Johno Crawford (johno@sulake.com)
 */
public class SimpleThreadFactory implements java.util.concurrent.ThreadFactory {
    /** The thread name prefix. */
    private final String threadNamePrefix;

    /** The thread index counter, used for assigning unique thread ids. */
    private static final AtomicInteger threadIdx = new AtomicInteger();

    /** Whether to set daemon mode. */
    private final boolean daemon;

    /**
     * Constructor.
     *
     * @param threadNamePrefix
     *            prefix for created threads.
     * @param daemon
     *            create daemon threads?
     */
    SimpleThreadFactory(final String threadNamePrefix, final boolean daemon) {
        this.threadNamePrefix = threadNamePrefix;
        this.daemon = daemon;
    }

    /**
     * New thread.
     *
     * @param runnable
     *            the runnable
     * @return the thread
     */
    @Override
    public Thread newThread(final Runnable runnable) {
        // Call System.getSecurityManager().getThreadGroup() via reflection, since it is deprecated in JDK 17
        ThreadGroup securityManagerThreadGroup = null;
        try {
            final Method getSecurityManager = System.class.getDeclaredMethod("getSecurityManager");
            final Object securityManager = getSecurityManager.invoke(null);
            if (securityManager != null) {
                // (Use getMethod() rather than getDeclaredMethod(), since getThreadGroup() is a public method
                // inherited from SecurityManager -- an installed security manager is almost always a subclass
                // that does not redeclare it, and getDeclaredMethod() would not find it in that case)
                final Method getThreadGroup = securityManager.getClass().getMethod("getThreadGroup");
                securityManagerThreadGroup = (ThreadGroup) getThreadGroup.invoke(securityManager);
            }
        } catch (final Throwable t) {
            // Fall through
        }
        // Use the current thread's ThreadGroup as the fallback, as java.util.concurrent.Executors'
        // defaultThreadFactory does. Allocating a new ThreadGroup per thread leaks: a ThreadGroup registers
        // itself with its parent on construction, and a non-daemon ThreadGroup is unregistered only when it is
        // explicitly destroyed, so one ThreadGroup (plus its Thread[] array) accumulated per created thread and
        // stayed reachable from the parent group forever. (#931)
        final Thread thread = new Thread(
                securityManagerThreadGroup != null ? securityManagerThreadGroup
                        : Thread.currentThread().getThreadGroup(),
                runnable, threadNamePrefix + threadIdx.getAndIncrement());
        thread.setDaemon(daemon);
        return thread;
    }
}
