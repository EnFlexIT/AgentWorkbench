/* ====================================================================
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
==================================================================== */

package org.apache.poi.openxml4j.exceptions;

import org.apache.poi.openxml4j.opc.PackagePart;

/**
 * Throw when trying to create a {@link PackagePart} but one
 *  already exists with that name.
 */
@SuppressWarnings("serial")
public final class PartAlreadyExistsException extends InvalidOperationException {
    public PartAlreadyExistsException(String message){
        super(message);
    }
}
