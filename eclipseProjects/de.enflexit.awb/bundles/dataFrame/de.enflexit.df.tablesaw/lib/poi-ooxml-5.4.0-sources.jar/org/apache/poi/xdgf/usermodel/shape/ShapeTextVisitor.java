/* ====================================================================
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
==================================================================== */
package org.apache.poi.xdgf.usermodel.shape;

import java.awt.geom.AffineTransform;

import org.apache.poi.xdgf.usermodel.XDGFShape;

/**
 * Only visits text nodes, accumulates text content into a string
 * 
 * The text is returned in arbitrary order, with no regards to
 * the location of the text on the page. This may change in the
 * future.
 */
public class ShapeTextVisitor extends ShapeVisitor {

    protected StringBuilder text = new StringBuilder();
    
    public static class TextAcceptor implements ShapeVisitorAcceptor {
        public boolean accept(XDGFShape shape) {
            return shape.hasText();
        }
    }
    
    protected ShapeVisitorAcceptor getAcceptor() {
        return new TextAcceptor();
    }

    public void visit(XDGFShape shape, AffineTransform globalTransform,
            int level) {
        text.append(shape.getText().getTextContent().trim());
        text.append('\n');
    }

    /**
     * Call this after visitation has completed
     */
    public String getText() {
        return text.toString();
    }

}
